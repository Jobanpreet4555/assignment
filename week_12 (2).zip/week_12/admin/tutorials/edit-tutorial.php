<?php
// Database connection information
$host = "localhost";
$username = "root";
$password = "";
$dbname = "assignment2";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $id = $_POST['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $video_url = $_POST['video_url'];
    
    // Update database
    $sql = "UPDATE tutorials SET title='$title', description='$description', video_url='$video_url' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: ../admin-index.php");
    } else {
        echo "Error updating record: " . $conn->error;
    }
}


// Fetch tutorial details based on ID
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $tutorial_query = "SELECT * FROM tutorials WHERE id=$id";
    $tutorial_result = mysqli_query($conn, $tutorial_query);
    $tutorial = mysqli_fetch_assoc($tutorial_result);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Tutorial</title>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

header {
    padding: 20px;
    text-align: center;
}

main {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

form {
    margin-top: 20px;
}

label {
    font-weight: bold;
}

input[type="text"],
textarea {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type="submit"],
button[type="button"] {
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type="submit"] {
    background-color: #4caf50;
    color: white;
}

button[type="button"] {
    background-color: #ccc;
    color: #555;
}

input[type="submit"]:hover {
    background-color: #45a049;
}

button[type="button"]:hover {
    background-color: #bbb;
}
</style>
</head>
<body>
    <header>
        <h1>Edit Tutorial</h1>
    </header>
    <main>
        <section>
            <h2>Edit Tutorial</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <input type="hidden" name="id" value="<?php echo $tutorial['id']; ?>">
                <label for="title">Title:</label><br>
                <input type="text" id="title" name="title" value="<?php echo $tutorial['title']; ?>"><br>
                <label for="video_url">Video URL:</label><br>
                <input type="text" id="video_url" name="video_url" value="<?php echo htmlspecialchars($tutorial['video_url']); ?>" class="form-input"><br> 
                <input type="submit" value="Update">
                <a href="../admin-index.php"><button type="button">Cancel</button></a>

            </form>
        </section>
    </main>
</body>
</html>
